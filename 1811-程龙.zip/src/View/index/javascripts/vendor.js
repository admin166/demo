
require('./modules/a')

console.log('vendor.js')