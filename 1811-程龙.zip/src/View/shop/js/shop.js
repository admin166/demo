require('./modules/shoplist');
require('./modules/lunbo');
require('./modules/big');


